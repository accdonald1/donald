@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo          GTA VI - EXE BUILDER
echo ==========================================
echo.

py -3 -m pip install --upgrade pip
if errorlevel 1 goto :error
py -3 -m pip install PySide6 PyInstaller
if errorlevel 1 goto :error

py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name "GTA VI" --icon "gta_vi.ico" --add-data "intro.mp4;." --add-data "gta_vi.ico;." gta_vi.py
if errorlevel 1 goto :error

echo.
echo Listo. Tu ejecutable esta en: dist\GTA VI.exe
echo Puedes copiar solamente ese EXE y enviarselo a tu amigo.
pause
exit /b 0

:error
echo.
echo Hubo un error al preparar el ejecutable. Revisa que Python 3 este instalado.
pause
exit /b 1
