import os
import sys
from pathlib import Path

from PySide6.QtCore import QUrl, QTimer, Qt
from PySide6.QtGui import QIcon, QColor, QKeyEvent
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget


def resource_path(name: str) -> str:
    """Resolve files both in development and inside a PyInstaller one-file build."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return str(base / name)


class PlayerWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GTA VI")
        self.setWindowIcon(QIcon(resource_path("gta_vi.ico")))
        self.setStyleSheet("background-color: #292929;")
        self.setCursor(Qt.CursorShape.BlankCursor)

        self.video = QVideoWidget(self)
        self.video.setStyleSheet("background-color: black;")
        self.video.setAspectRatioMode(Qt.AspectRatioMode.KeepAspectRatio)
        self.video.hide()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.video)

        self.audio = QAudioOutput(self)
        self.player = QMediaPlayer(self)
        self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video)
        self.player.mediaStatusChanged.connect(self.on_media_status)
        self.player.errorOccurred.connect(self.on_error)

        self.player.setSource(QUrl.fromLocalFile(resource_path("intro.mp4")))
        self.showFullScreen()
        QTimer.singleShot(3000, self.start_video)

    def start_video(self):
        self.setStyleSheet("background-color: black;")
        self.video.show()
        self.player.setPosition(0)
        self.player.play()

    def on_media_status(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.player.stop()
            self.video.hide()
            self.setStyleSheet("background-color: black;")
            self.unsetCursor()

    def on_error(self, error, message):
        if error != QMediaPlayer.Error.NoError:
            # Keep the app clean and fullscreen if the media backend reports an error.
            self.setStyleSheet("background-color: black;")

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("GTA VI")
    app.setWindowIcon(QIcon(resource_path("gta_vi.ico")))
    window = PlayerWindow()
    sys.exit(app.exec())
